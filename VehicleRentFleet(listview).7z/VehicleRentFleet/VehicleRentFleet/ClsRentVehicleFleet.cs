﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentFleet
{
    [Serializable]
    class ClsRentVehicleFleet
    {
        private static string _FileName = "D:\\GIT\\sdv601\\project using dictionary\\VehicleRentFleet\\dataSaverv2.dat";

        private static SortedDictionary<string, ClsVehicle> _FleetList = new SortedDictionary<string, ClsVehicle>();

        public static SortedDictionary<string, ClsVehicle> FleetList { get => _FleetList; set => _FleetList = value; }

        public static void SaveData()
        {
            using (FileStream lcFileStream = new FileStream(_FileName, FileMode.Create))
            {
                BinaryFormatter lcFormatter = new BinaryFormatter();
                lcFormatter.Serialize(lcFileStream, _FleetList);
                BinaryFormatter lcFormatter_ = new BinaryFormatter();
                lcFormatter_.Serialize(lcFileStream, ClsVehicle.ActivityList);
            }
        }

        public static void RetrieveData()
        {
            using (FileStream lcFileStream = new FileStream(_FileName, FileMode.Open))
            {
                BinaryFormatter lcFormatter = new BinaryFormatter();
                BinaryFormatter lcFormatter_ = new BinaryFormatter();
                _FleetList = (SortedDictionary<string, ClsVehicle>)lcFormatter.Deserialize(lcFileStream);
                ClsVehicle.ActivityList = (Dictionary<String, ClsActivity>)lcFormatter_.Deserialize(lcFileStream);
            }
        }
    }
}
