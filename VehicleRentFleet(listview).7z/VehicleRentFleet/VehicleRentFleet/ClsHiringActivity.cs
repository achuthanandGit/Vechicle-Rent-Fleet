﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentFleet
{

    [Serializable]
    class ClsHiringActivity : ClsActivity
    {
        private DateTime _HireEndDate;
        private static FrmHiringActivity _Form = new FrmHiringActivity();
        private int _DailyCharge;

        public ClsHiringActivity(int charge)
        {
            DailyCharge = charge;
        }

        public DateTime HireEndDate { get => _HireEndDate; set => _HireEndDate = value; }
        public int DailyCharge { get => _DailyCharge; set => _DailyCharge = value; }

        public override bool ViewEditActivity()
        {
            return _Form.ShowDialog(this);
        }

        public override string typeOfActivity()
        {
            return "Hiring";
        }
        
        public override string GetQuickView()
        {
            return "Actvity Name: " + this.ActivityName +
                  "\nStart Date: " + this.ActivityDate +
                  "\nEnd Data: " + this.HireEndDate +
                  "\nActivity Cost: " + this.ActivityCost;
        }
    }
}
