﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentFleet
{
    [Serializable]
    class ClsServiceActivity : ClsActivity
    {
        private string _ServiceBrief;

       private static FrmServiceActivity _Form = new FrmServiceActivity();

        public string ServiceBrief { get => _ServiceBrief; set => _ServiceBrief = value; }

        public override bool ViewEditActivity()
        {
            return _Form.ShowDialog(this);
        }

        public override string typeOfActivity()
        {
            return "Service";
        }
        
        public override string GetQuickView()
        {
            return "Actvity Name: " + this.ActivityName +
                    "\nActivity Date: " + this.ActivityDate +
                    "\nService Brief: " + this.ServiceBrief +
                    "\nActivity Cost: " + -this.ActivityCost;
        }
    }
    
}
