﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VehicleRentFleet
{
    public partial class FrmActivityDashboard : Form
    {
        ClsVehicle _LcVehicle = new ClsVehicle();
        public FrmActivityDashboard()
        {
            InitializeComponent();
            SetButtonToolTips();
        }

        private void SetButtonToolTips()
        {
            System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();
            ToolTip1.SetToolTip(this.buttonAddActivity, "Add New");
            ToolTip1.SetToolTip(this.buttonClose, "Close");
        }

        internal void ShowDialog(ClsVehicle prVehicle)
        {
            _LcVehicle = prVehicle;
            LoadComboBoxValues();
            SetAllDefaultSettings();
            LoadActivityList(comboBoxSortBy.Text);
            ShowDialog();
        }

        private void LoadActivityList(string sortType)
        {
            List<ClsActivity> activityList = GetSortedList(ClsVehicle.ActivityList.Values.ToList<ClsActivity>(), sortType);
            activityList = activityList.FindAll(delegate (ClsActivity lcActivity)
            {
                return lcActivity.RegistrationNumber.Equals(_LcVehicle.RegistrationNumber);
            });
            LoadActivtyListView(activityList);
            decimal cashFlow = ClsVehicle.CalculateCashFlow(_LcVehicle.RegistrationNumber);
            labelVehicleCashFlow.Text = "Cashflow: " + cashFlow + " NZ$";
        }

        private List<ClsActivity> GetSortedList(List<ClsActivity> activityList, string sortType)
        {
            if("Activity Name" == sortType)
            {
                ClsSortByName sortByName = new ClsSortByName();
                activityList.Sort(sortByName);
            } else
            {
                ClsSortByDate sortByDate = new ClsSortByDate();
                activityList.Sort(sortByDate);
            }
            return activityList;
        }

        private void LoadActivtyListView(List<ClsActivity> activityList)
        {
            listViewActivityList.Items.Clear();
            if (activityList.Any())
            {
                foreach (ClsActivity lcActivity in activityList)
                {
                    ListViewItem listViewItem = new ListViewItem(lcActivity.ActivityUpdatedTime.ToString());
                    listViewItem.SubItems.Add(lcActivity.ActivityName.ToString());
                    listViewItem.SubItems.Add(lcActivity.ActivityUpdatedTime.ToString());
                    listViewItem.SubItems.Add(lcActivity.typeOfActivity());
                    if("Hiring" != lcActivity.typeOfActivity())
                        listViewItem.SubItems.Add((-lcActivity.ActivityCost).ToString());
                    else
                        listViewItem.SubItems.Add(lcActivity.ActivityCost.ToString());
                    listViewActivityList.Items.Add(listViewItem);
                }
            }
        }

        private void SetAllDefaultSettings()
        {
            labelRegistrationNumber.Text = _LcVehicle.RegistrationNumber;
            comboBoxType.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSortBy.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxType.Text = "Hiring";
            comboBoxSortBy.Text = "Activity Name";
        }

        private void LoadComboBoxValues()
        {
            comboBoxSortBy.DataSource = ClsActivity.SortType;
            comboBoxType.DataSource = ClsActivity.ActivityType;
        }

        private void buttonAddActivity_Click(object sender, EventArgs e)
        {
            string activityType = comboBoxType.Text;
            ClsActivity lcActivity = ClsActivity.NewActivity(activityType, _LcVehicle.DailyCharge);
            lcActivity.ActivityDate = DateTime.Now;
            if (lcActivity.ViewEditActivity())
            { 
                lcActivity.RegistrationNumber = _LcVehicle.RegistrationNumber;
                DateTime updatedDateTime = DateTime.Now;
                lcActivity.ActivityUpdatedTime = updatedDateTime;
                ClsVehicle.ActivityList.Add(updatedDateTime.ToString(), lcActivity);
                LoadActivityList(comboBoxSortBy.Text);
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            ClsRentVehicleFleet.SaveData();
            richTextBoxViewActivity.Clear();
            Close();
        }
        

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditActivity();
        }

        private void EditActivity()
        {
            richTextBoxViewActivity.Clear();
            string activityUpdatedDateTime = listViewActivityList.SelectedItems[0].Text;
            string activityType = listViewActivityList.SelectedItems[0].SubItems[3].Text;
            List<ClsActivity> activityList = ClsVehicle.ActivityList.Values.ToList<ClsActivity>();
            activityList = activityList.FindAll(delegate (ClsActivity activity)
            {
                return activity.RegistrationNumber.Equals(_LcVehicle.RegistrationNumber) &&
                activity.ActivityUpdatedTime.ToString() == (activityUpdatedDateTime);
            });
            ClsActivity selectedActivity = null;
            if (activityType == "Hiring")
            {
                selectedActivity = (ClsHiringActivity)activityList[0];
            }
            else if (activityType == "Service")
                selectedActivity = (ClsServiceActivity)activityList[0];
            else
                selectedActivity = (ClsRelocationActivity)activityList[0];
            if(selectedActivity.ViewEditActivity())
            {
                String createdDateTime = selectedActivity.ActivityUpdatedTime.ToString();
                ClsVehicle.ActivityList.Remove(createdDateTime);
                ClsVehicle.ActivityList.Add(createdDateTime,selectedActivity);
                LoadActivityList(comboBoxSortBy.Text);
            }
            
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxViewActivity.Clear();
            string activityUpdatedDateTime = listViewActivityList.SelectedItems[0].Text;
            string activityType = listViewActivityList.SelectedItems[0].SubItems[3].Text;
            if(DialogResult.OK == MessageBox.Show("Are you sure want to delete?", 
                "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error))
            {
                ClsVehicle.ActivityList.Remove(activityUpdatedDateTime);
                LoadActivityList(comboBoxSortBy.Text);
            }
        }

        

        private void GetQuickView(string activityUpdatedDateTime, string activityType)
        {   
            List<ClsActivity> activityList = ClsVehicle.ActivityList.Values.ToList<ClsActivity>();
            activityList = activityList.FindAll(delegate (ClsActivity activity)
            {
                return activity.RegistrationNumber.Equals(_LcVehicle.RegistrationNumber) &&
                activity.ActivityUpdatedTime.ToString() == (activityUpdatedDateTime);
            });
            if (activityType == "Hiring")
            {
                richTextBoxViewActivity.Text = ((ClsHiringActivity)activityList[0]).GetQuickView();
            }   
            else if(activityType == "Service")
            {
                richTextBoxViewActivity.Text = ((ClsServiceActivity)activityList[0]).GetQuickView();
            }
            else
            {
                richTextBoxViewActivity.Text = ((ClsRelocationActivity)activityList[0]).GetQuickView();
            }
                
        }

        private void contextMenuActivity_Opening(object sender, CancelEventArgs e)
        {
            if (listViewActivityList.SelectedItems.Count == 0)
                e.Cancel = true;
        }

        private void listViewActivityList_Click(object sender, EventArgs e)
        {
            string activityUpdatedDateTime = listViewActivityList.SelectedItems[0].Text;
            string activityType = listViewActivityList.SelectedItems[0].SubItems[3].Text;
            GetQuickView(activityUpdatedDateTime, activityType);
        }

        private void comboBoxSortBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadActivityList(comboBoxSortBy.Text);
        }
    }
}
