﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentFleet
{
    class ClsSortByName : IComparer<ClsActivity>
    {
        public int Compare(ClsActivity activityOne, ClsActivity activityTwo)
        {
            return activityOne.ActivityName.CompareTo(activityTwo.ActivityName);
        }
    }
}
