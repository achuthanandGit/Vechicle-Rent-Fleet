﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentFleet
{
    [Serializable]
    public class ClsVehicle
    {
        private static FrmManageVehicle _Form = new FrmManageVehicle();
        private int _VehicleId;
        private string _RegistrationNumber;
        private string _VehicleMake;
        private string _VehicleModel;
        private int _VehicleYear;
        private int _DailyCharge;
        private static Dictionary<String, ClsActivity> _ActivityList = new Dictionary<String, ClsActivity>();
   
        public int VehicleId { get => _VehicleId; set => _VehicleId = value; }
        public string RegistrationNumber { get => _RegistrationNumber; set => _RegistrationNumber = value; }
        public string VehicleMake { get => _VehicleMake; set => _VehicleMake = value; }
        public string VehicleModel { get => _VehicleModel; set => _VehicleModel = value; }
        public int VehicleYear { get => _VehicleYear; set => _VehicleYear = value; }
        public int DailyCharge { get => _DailyCharge; set => _DailyCharge = value; }
        public static Dictionary<String, ClsActivity> ActivityList { get => _ActivityList; set => _ActivityList = value; }

        public string GetQuickView()
        {
            return " Reg no: " + RegistrationNumber + "\n" +
               " Make: " + VehicleMake + "\n" +
               " Model: " + VehicleModel + "\n" +
               " Year: " + VehicleYear + "\n" +
               " Hire Value: " + DailyCharge + "NZ$";
        }

        public bool ViewEditVehicle()
        {
            return _Form.ShowDialog(this);
        }

        public static decimal CalculateCashFlow(string registrationNumber)
        {
            decimal totalCashFlow = 0;
            if(string.IsNullOrEmpty(registrationNumber))
            {
                foreach (ClsActivity lcActivity in _ActivityList.Values)
                    totalCashFlow = totalCashFlow + lcActivity.ActivityCost;
            } else
            {
                foreach (ClsActivity lcActivity in _ActivityList.Values)
                    if(registrationNumber == lcActivity.RegistrationNumber)
                        totalCashFlow = totalCashFlow + lcActivity.ActivityCost;
            }
            return totalCashFlow;
        }
    }
}

