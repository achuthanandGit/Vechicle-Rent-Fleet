﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentFleet
{
    
    [Serializable]
    public abstract class ClsActivity
    {
        private DateTime _ActivityUpdatedTime;
        private String _RegistrationNumber;
        private string _ActivityName;
        private DateTime _ActivityDate;
        private decimal _ActivityCost;

        private static readonly string[] activityType = { "Hiring", "Service", "Relocation" };
        private static readonly string[] sortType = { "Activity Name", "Activity Date" };

        public string RegistrationNumber { get => _RegistrationNumber; set => _RegistrationNumber = value; }
        public string ActivityName { get => _ActivityName; set => _ActivityName = value; }
        public DateTime ActivityDate { get => _ActivityDate; set => _ActivityDate = value; }
        public decimal ActivityCost { get => _ActivityCost; set => _ActivityCost = value; }

        public static string[] ActivityType => activityType;

        public static string[] SortType => sortType;

        public DateTime ActivityUpdatedTime { get => _ActivityUpdatedTime; set => _ActivityUpdatedTime = value; }

        public static ClsActivity NewActivity(string activityType, int dailyCharge)
        {
            switch (activityType)
            {
                case "Service":
                    return new ClsServiceActivity();
                case "Relocation":
                    return new ClsRelocationActivity();
                default:
                    return new ClsHiringActivity(dailyCharge);
            }
        }

        public abstract string typeOfActivity();

        public abstract bool ViewEditActivity();

        public abstract string GetQuickView();

        
    }
}
