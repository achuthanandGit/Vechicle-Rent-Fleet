﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace VehicleRentFleet
{
    public partial class FrmHiringActivity : VehicleRentFleet.FrmActivity
    {
        ClsHiringActivity lcActivity;
        public FrmHiringActivity()
        {
            InitializeComponent();
        }

        protected override void UpdateFormData()
        {
            lcActivity = (ClsHiringActivity)_LcActivity;
            
            if(!String.IsNullOrEmpty(lcActivity.ActivityName))
            {
                dateTimePickerEndDate.Value = lcActivity.HireEndDate;
                numericUpDownCharge.Value = lcActivity.ActivityCost;
            }
            else
                numericUpDownCharge.Value = lcActivity.DailyCharge;
            base.UpdateFormData();
        }
       
        protected override string GetDataValidationMessage()
        {
            string lcValidationMessage = base.GetDataValidationMessage();
            if (String.IsNullOrWhiteSpace(lcValidationMessage))
            {
                if (DateTime.Compare(dateTimePickerDate.Value, dateTimePickerEndDate.Value) > 0)
                    return "Start date cannot be after End date.";
                else
                    return string.Empty;
            }else
                return lcValidationMessage;
        }


        protected override void PushFormData()
        {
            base.PushFormData();
            ClsHiringActivity lcActivity = (ClsHiringActivity)_LcActivity;
            lcActivity.HireEndDate = dateTimePickerEndDate.Value;
            lcActivity.ActivityCost = (numericUpDownCharge.Value);
            lcActivity.DailyCharge = lcActivity.DailyCharge;
        }

        private void dateTimePickerDate_ValueChanged(object sender, EventArgs e)
        {
            CheckHiringDate();
        }

        private void dateTimePickerEndDate_ValueChanged(object sender, EventArgs e)
        {
            CheckHiringDate();
        }


        private void CheckHiringDate()
        {
            if (DateTime.Compare(dateTimePickerDate.Value, dateTimePickerEndDate.Value) <= 0)
            {
                DateTime startDate = dateTimePickerDate.Value;
                DateTime endDate = dateTimePickerEndDate.Value;
                int daysDifference = ((TimeSpan)(endDate - startDate)).Days + 1;
                decimal totalCharge = daysDifference * lcActivity.DailyCharge;
                labelHireCalculation.Text = lcActivity.DailyCharge + " * " + daysDifference + " = ";
                numericUpDownCharge.Value = totalCharge;
            }
            else
                MessageBox.Show("Start date cannot be after End date.", "Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }
}
